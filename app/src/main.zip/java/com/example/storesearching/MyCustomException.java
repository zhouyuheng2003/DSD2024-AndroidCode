package com.example.storesearching;

public class MyCustomException extends Exception {
    public MyCustomException(String message) {
        super(message);
    }
}