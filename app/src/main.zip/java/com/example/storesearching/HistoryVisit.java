package com.example.storesearching;

public class HistoryVisit {
    public Integer storeId;
    public String dataTime;
    public HistoryVisit(Integer storeId, String dataTime){
        this.storeId = storeId;
        this.dataTime = dataTime;
    }
}
